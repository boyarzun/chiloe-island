/*
* Carousel - Advanced UI 
*/
$(function () {
  // Carousel
  $('.carousel').carousel();
  // Full Width Slider
  $('.carousel.carousel-slider').carousel({ fullWidth: true });
  // Special Options
  $('.carousel.carousel-slider').carousel({ fullWidth: true });

  $('.carousel.carousel-slider.carousel-indicators').carousel({
    fullWidth: true,
    indicators: true
  });
});
